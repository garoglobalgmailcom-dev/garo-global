# MACA by GARO — Guide d'installation du Backend

## Structure des fichiers

```
maca_garo_backend/
├── server.js           ← Le serveur backend (ce fichier)
├── package.json        ← Dépendances Node.js
├── maca_garo_v5.html   ← Votre interface (copiez-la ici)
├── README.md           ← Ce guide
└── db/                 ← Base de données (créée automatiquement)
    ├── offres.json
    ├── negotiations.json
    ├── verifications.json
    └── messages.json
```

---

## Installation (une seule fois)

### 1. Installer Node.js
Téléchargez et installez Node.js depuis https://nodejs.org (version 16 ou plus)

Vérifiez l'installation :
```bash
node --version
npm --version
```

### 2. Installer les dépendances
Dans le dossier du projet :
```bash
npm install
```

---

## Démarrage

```bash
node server.js
```

Vous devriez voir :
```
  ╔══════════════════════════════════════════════════╗
  ║   MACA by GARO — Backend opérationnel           ║
  ╠══════════════════════════════════════════════════╣
  ║  🌐  Interface  :  http://localhost:3000          ║
  ║  📦  API Offres :  http://localhost:3000/api/offres ║
  ╚══════════════════════════════════════════════════╝
```

Ouvrez votre navigateur sur **http://localhost:3000**

---

## Endpoints API

| Méthode | URL | Description |
|---------|-----|-------------|
| `POST` | `/api/offres` | Publier une offre |
| `GET` | `/api/offres` | Lister les offres |
| `GET` | `/api/offres/:id` | Détail d'une offre |
| `DELETE` | `/api/offres/:id` | Supprimer une offre |
| `GET` | `/api/dashboard/stats` | KPIs du dashboard |
| `GET` | `/api/prix` | Prix en temps réel |
| `POST` | `/api/verifications` | Déclarer un stock |
| `GET` | `/api/verifications` | Lister les certifications |
| `POST` | `/api/negotiations` | Ouvrir une négociation |

---

## Indicateur de connexion

Un badge apparaît en bas à droite de l'interface :
- 🟢 **Backend actif** — toutes les fonctions sont opérationnelles
- 🔴 **Backend offline** — l'interface fonctionne en mode local (sans persistance)

---

## Mode développement (rechargement automatique)

```bash
npm run dev
```
Nécessite `nodemon` (inclus dans les dépendances de dev).

---

## Prochaines étapes

1. **Authentification** : Remplacer `vendeur: 'Anonyme'` par un vrai système de login
2. **Base de données SQL** : Migrer de JSON vers PostgreSQL ou MySQL pour de grands volumes
3. **Upload de fichiers** : Ajouter `multer` pour les preuves de certification (photos, PDF)
4. **WebSocket** : Ajouter `socket.io` pour les prix et chats en temps réel
5. **Déploiement** : Héberger sur Railway, Render, ou un VPS local
