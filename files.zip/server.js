/**
 * ═══════════════════════════════════════════════════════════════
 *  MACA by GARO — Backend API Server
 *  Marché Africain des Commodités Agricoles
 *  Version 1.0.0
 * ═══════════════════════════════════════════════════════════════
 *
 *  INSTALLATION :
 *    1. npm install
 *    2. node server.js
 *
 *  Le serveur démarre sur http://localhost:3000
 *
 *  ENDPOINTS DISPONIBLES :
 *    POST   /api/offres          → Publier une nouvelle offre
 *    GET    /api/offres          → Lister toutes les offres
 *    GET    /api/offres/:id      → Détail d'une offre
 *    DELETE /api/offres/:id      → Supprimer une offre
 *    GET    /api/dashboard/stats → Statistiques du dashboard
 *    GET    /api/prix            → Prix en temps réel (simulé)
 *    POST   /api/negotiations    → Créer une négociation
 *    GET    /api/negotiations    → Lister les négociations
 *    POST   /api/verifications   → Soumettre une déclaration de stock
 *    GET    /api/verifications   → Lister les certifications
 */

const express = require('express');
const cors    = require('cors');
const fs      = require('fs');
const path    = require('path');
const { v4: uuidv4 } = require('uuid');

const app  = express();
const PORT = process.env.PORT || 3000;

// ─── MIDDLEWARE ───────────────────────────────────────────────────────────────
app.use(cors());                        // Autorise les requêtes depuis votre HTML
app.use(express.json());               // Parse le JSON entrant
app.use(express.static(__dirname));    // Sert les fichiers statiques (le .html)

// ─── UTILITAIRES BASE DE DONNÉES (fichiers JSON) ──────────────────────────────
const DB_DIR = path.join(__dirname, 'db');

// Crée le dossier db/ s'il n'existe pas
if (!fs.existsSync(DB_DIR)) fs.mkdirSync(DB_DIR);

function readDB(filename) {
  const filePath = path.join(DB_DIR, filename);
  if (!fs.existsSync(filePath)) return [];
  try {
    return JSON.parse(fs.readFileSync(filePath, 'utf8'));
  } catch {
    return [];
  }
}

function writeDB(filename, data) {
  const filePath = path.join(DB_DIR, filename);
  fs.writeFileSync(filePath, JSON.stringify(data, null, 2));
}

// Initialise les fichiers DB s'ils n'existent pas
const DB_FILES = {
  'offres.json':        [],
  'negotiations.json':  [],
  'verifications.json': [],
  'messages.json':      [],
};

Object.entries(DB_FILES).forEach(([file, defaultData]) => {
  const filePath = path.join(DB_DIR, file);
  if (!fs.existsSync(filePath)) {
    writeDB(file, defaultData);
    console.log(`  ✅ Base créée : db/${file}`);
  }
});


// ══════════════════════════════════════════════════════════════════════════════
//  ROUTES — OFFRES (Publish an Offer)
// ══════════════════════════════════════════════════════════════════════════════

/**
 * POST /api/offres
 * Corps attendu :
 * {
 *   categorie:   "cash",          // Clé de catégorie
 *   produit:     "Cocoa",         // Nom du produit
 *   quantite:    80,              // En Tonnes
 *   prix:        3840,            // En $/Tonne
 *   pays:        "🇨🇮 Côte d'Ivoire",
 *   qualite:     "Grade A, RFA Certified, 6.5% moisture",
 *   livraison:   "FOB Port of Origin",
 *   vendeur:     "Amara Diallo",  // (optionnel — futur auth)
 * }
 */
app.post('/api/offres', (req, res) => {
  const { categorie, produit, quantite, prix, pays, qualite, livraison, vendeur } = req.body;

  // Validation des champs obligatoires
  if (!produit || !quantite || !prix || !pays) {
    return res.status(400).json({
      erreur: 'Champs manquants : produit, quantite, prix et pays sont obligatoires.'
    });
  }

  const offres = readDB('offres.json');

  // Construction de l'offre avec ID GARO (format GA-XXXXXXXX)
  const nouvelleOffre = {
    id:          `GA-${Date.now().toString(36).toUpperCase()}`,
    uuid:        uuidv4(),
    categorie:   categorie || 'autre',
    produit,
    quantite:    Number(quantite),
    prix:        Number(prix),
    pays,
    qualite:     qualite || '',
    livraison:   livraison || 'Ex-Farm',
    vendeur:     vendeur || 'Utilisateur anonyme',
    statut:      'active',
    dateCreation: new Date().toISOString(),
    vues:        0,
    contacts:    0,
  };

  offres.unshift(nouvelleOffre); // Ajoute en tête de liste (plus récent en premier)
  writeDB('offres.json', offres);

  console.log(`  📦 Nouvelle offre publiée : [${nouvelleOffre.id}] ${produit} — ${quantite}T @ $${prix}/T`);

  res.status(201).json({
    succes: true,
    message: `Offre publiée avec succès sur le réseau GARO !`,
    offre: nouvelleOffre,
  });
});


/**
 * GET /api/offres
 * Paramètres de filtre optionnels :
 *   ?produit=Cocoa
 *   ?categorie=cash
 *   ?pays=Ivory+Coast
 *   ?limite=20
 *   ?statut=active
 */
app.get('/api/offres', (req, res) => {
  let offres = readDB('offres.json');
  const { produit, categorie, pays, limite, statut } = req.query;

  // Filtres
  if (produit)   offres = offres.filter(o => o.produit.toLowerCase().includes(produit.toLowerCase()));
  if (categorie) offres = offres.filter(o => o.categorie === categorie);
  if (pays)      offres = offres.filter(o => o.pays.toLowerCase().includes(pays.toLowerCase()));
  if (statut)    offres = offres.filter(o => o.statut === statut);

  // Limite de résultats
  const max = parseInt(limite) || 100;
  offres = offres.slice(0, max);

  res.json({
    total: offres.length,
    offres,
  });
});


/**
 * GET /api/offres/:id
 * Retourne une offre par son ID GARO (ex: GA-M5X2A0)
 */
app.get('/api/offres/:id', (req, res) => {
  const offres = readDB('offres.json');
  const offre  = offres.find(o => o.id === req.params.id || o.uuid === req.params.id);

  if (!offre) {
    return res.status(404).json({ erreur: `Offre ${req.params.id} introuvable.` });
  }

  // Incrémente le compteur de vues
  offre.vues = (offre.vues || 0) + 1;
  writeDB('offres.json', offres);

  res.json(offre);
});


/**
 * DELETE /api/offres/:id
 * Supprime ou désactive une offre
 */
app.delete('/api/offres/:id', (req, res) => {
  const offres  = readDB('offres.json');
  const index   = offres.findIndex(o => o.id === req.params.id);

  if (index === -1) {
    return res.status(404).json({ erreur: `Offre ${req.params.id} introuvable.` });
  }

  // Désactivation soft (conserve l'historique)
  offres[index].statut = 'supprimée';
  writeDB('offres.json', offres);

  console.log(`  🗑️  Offre désactivée : [${req.params.id}]`);
  res.json({ succes: true, message: 'Offre retirée du marché.' });
});


// ══════════════════════════════════════════════════════════════════════════════
//  ROUTES — DASHBOARD STATS
// ══════════════════════════════════════════════════════════════════════════════

/**
 * GET /api/dashboard/stats
 * Retourne les KPIs calculés depuis la base réelle + données simulées pour les prix
 */
app.get('/api/dashboard/stats', (req, res) => {
  const offres        = readDB('offres.json');
  const negotiations  = readDB('negotiations.json');
  const verifications = readDB('verifications.json');

  const offresActives = offres.filter(o => o.statut === 'active');

  // Calcule le volume total estimé (quantite * prix)
  const volumeTotal = offresActives.reduce((sum, o) => sum + (o.quantite * o.prix), 0);

  // Pays uniques
  const paysUniques = [...new Set(offresActives.map(o => o.pays))];

  // Catégories et leur répartition
  const repartition = {};
  offresActives.forEach(o => {
    repartition[o.categorie] = (repartition[o.categorie] || 0) + 1;
  });

  res.json({
    offresActives:      offresActives.length,
    paysCouverts:       paysUniques.length,
    produiteursVerifies: verifications.filter(v => v.statut === 'certified').length,
    volumeMensuel:      volumeTotal,
    volumeMensuelFmt:   volumeTotal >= 1000000
                          ? `$${(volumeTotal / 1000000).toFixed(1)}M`
                          : `$${(volumeTotal / 1000).toFixed(0)}K`,
    negotiations:       negotiations.length,
    repartitionCategories: repartition,
    dernieresOffres:    offresActives.slice(0, 5),
  });
});


// ══════════════════════════════════════════════════════════════════════════════
//  ROUTES — PRIX EN TEMPS RÉEL (simulé + persisté)
// ══════════════════════════════════════════════════════════════════════════════

// Données de prix de base — mise à jour périodique simulée
let PRIX_BASE = [
  { emoji:'🌽', name:'Maize',     price:218,   chg:+2.4  },
  { emoji:'☕', name:'Cocoa',     price:3840,  chg:+0.8  },
  { emoji:'🫘', name:'Soybean',   price:490,   chg:-1.2  },
  { emoji:'🌻', name:'Sesame',    price:1120,  chg:+3.1  },
  { emoji:'🥜', name:'Groundnut', price:780,   chg:-0.4  },
  { emoji:'🌾', name:'Wheat',     price:302,   chg:-0.3  },
  { emoji:'☕', name:'Coffee',    price:4200,  chg:+1.7  },
  { emoji:'🌿', name:'Ginger',    price:1400,  chg:+5.2  },
  { emoji:'🌴', name:'Palm Oil',  price:890,   chg:-0.9  },
  { emoji:'🫒', name:'Olive Oil', price:3200,  chg:+0.6  },
  { emoji:'🍵', name:'Tea',       price:3100,  chg:+0.2  },
  { emoji:'🌸', name:'Vanilla',   price:28000, chg:-1.8  },
];

// Simule la variation de prix toutes les 10 secondes côté serveur
setInterval(() => {
  PRIX_BASE = PRIX_BASE.map(p => {
    const delta = (Math.random() - 0.5) * 0.4;
    return {
      ...p,
      chg:   Math.round((p.chg + delta) * 10) / 10,
      price: Math.max(1, Math.round(p.price * (1 + delta / 100))),
    };
  });
}, 10000);

/**
 * GET /api/prix
 * Retourne les prix actuels de toutes les matières premières
 */
app.get('/api/prix', (req, res) => {
  res.json({
    timestamp: new Date().toISOString(),
    prix: PRIX_BASE,
  });
});

/**
 * GET /api/prix/:nom
 * Retourne le prix d'une matière spécifique
 */
app.get('/api/prix/:nom', (req, res) => {
  const item = PRIX_BASE.find(p => p.name.toLowerCase() === req.params.nom.toLowerCase());
  if (!item) return res.status(404).json({ erreur: `Prix de "${req.params.nom}" introuvable.` });
  res.json({ ...item, timestamp: new Date().toISOString() });
});


// ══════════════════════════════════════════════════════════════════════════════
//  ROUTES — NÉGOCIATIONS (Chat)
// ══════════════════════════════════════════════════════════════════════════════

/**
 * POST /api/negotiations
 * Ouvre une nouvelle négociation sur une offre
 */
app.post('/api/negotiations', (req, res) => {
  const { offreId, acheteur, message } = req.body;

  if (!offreId || !acheteur || !message) {
    return res.status(400).json({ erreur: 'offreId, acheteur et message sont requis.' });
  }

  const negotiations = readDB('negotiations.json');

  const nego = {
    id:          `NEGO-${Date.now().toString(36).toUpperCase()}`,
    offreId,
    acheteur,
    statut:      'ouvert',
    dateCreation: new Date().toISOString(),
    messages: [
      {
        id:     uuidv4(),
        auteur: acheteur,
        texte:  message,
        date:   new Date().toISOString(),
      }
    ],
  };

  negotiations.unshift(nego);
  writeDB('negotiations.json', negotiations);

  console.log(`  💬 Négociation ouverte : [${nego.id}] sur offre ${offreId}`);
  res.status(201).json({ succes: true, negotiation: nego });
});


/**
 * GET /api/negotiations
 * Retourne toutes les négociations
 */
app.get('/api/negotiations', (req, res) => {
  const negotiations = readDB('negotiations.json');
  res.json({ total: negotiations.length, negotiations });
});


/**
 * POST /api/negotiations/:id/messages
 * Ajoute un message dans une négociation existante
 */
app.post('/api/negotiations/:id/messages', (req, res) => {
  const { auteur, texte } = req.body;

  if (!auteur || !texte) {
    return res.status(400).json({ erreur: 'auteur et texte sont requis.' });
  }

  const negotiations = readDB('negotiations.json');
  const nego = negotiations.find(n => n.id === req.params.id);

  if (!nego) return res.status(404).json({ erreur: 'Négociation introuvable.' });

  const msg = {
    id:     uuidv4(),
    auteur,
    texte,
    date:   new Date().toISOString(),
  };

  nego.messages.push(msg);
  nego.dernierMessage = new Date().toISOString();
  writeDB('negotiations.json', negotiations);

  res.status(201).json({ succes: true, message: msg });
});


// ══════════════════════════════════════════════════════════════════════════════
//  ROUTES — VÉRIFICATIONS DE STOCK
// ══════════════════════════════════════════════════════════════════════════════

/**
 * POST /api/verifications
 * Soumet une déclaration de stock pour certification
 */
app.post('/api/verifications', (req, res) => {
  const { produit, quantite, pays, ville, producteur } = req.body;

  if (!produit || !quantite || !pays) {
    return res.status(400).json({ erreur: 'produit, quantite et pays sont requis.' });
  }

  const verifications = readDB('verifications.json');

  const verif = {
    id:             `VC-${new Date().getFullYear()}-${String(verifications.length + 1).padStart(4, '0')}`,
    produit,
    quantite:       Number(quantite),
    pays,
    ville:          ville || '',
    producteur:     producteur || 'Anonyme',
    statut:         'pending',
    preuves:        [],
    inspecteur:     null,
    dateDeclaration: new Date().toISOString(),
    dateCertification: null,
    dateExpiration: null,
  };

  verifications.unshift(verif);
  writeDB('verifications.json', verifications);

  console.log(`  🔐 Déclaration soumise : [${verif.id}] ${produit} — ${quantite}T`);

  res.status(201).json({
    succes: true,
    message: 'Déclaration soumise. Un inspecteur vous contactera sous 48h.',
    verification: verif,
  });
});


/**
 * GET /api/verifications
 * Retourne toutes les certifications
 */
app.get('/api/verifications', (req, res) => {
  const verifications = readDB('verifications.json');
  const { statut }    = req.query;
  const filtered      = statut ? verifications.filter(v => v.statut === statut) : verifications;
  res.json({ total: filtered.length, verifications: filtered });
});


// ══════════════════════════════════════════════════════════════════════════════
//  ROUTE PRINCIPALE — Sert le fichier HTML
// ══════════════════════════════════════════════════════════════════════════════

app.get('/', (req, res) => {
  // Essaie de servir le fichier HTML MACA dans le même dossier
  const htmlPath = path.join(__dirname, 'maca_garo_v5.html');
  if (fs.existsSync(htmlPath)) {
    res.sendFile(htmlPath);
  } else {
    res.json({
      message: '⚠️  Placez votre fichier maca_garo_v5.html dans le même dossier que server.js',
      api: {
        offres:         'GET/POST /api/offres',
        stats:          'GET /api/dashboard/stats',
        prix:           'GET /api/prix',
        negotiations:   'GET/POST /api/negotiations',
        verifications:  'GET/POST /api/verifications',
      }
    });
  }
});


// ─── DÉMARRAGE ────────────────────────────────────────────────────────────────
app.listen(PORT, () => {
  console.log('\n');
  console.log('  ╔══════════════════════════════════════════════════╗');
  console.log('  ║   MACA by GARO — Backend opérationnel           ║');
  console.log('  ╠══════════════════════════════════════════════════╣');
  console.log(`  ║  🌐  Interface  :  http://localhost:${PORT}           ║`);
  console.log(`  ║  📦  API Offres :  http://localhost:${PORT}/api/offres ║`);
  console.log(`  ║  📊  Dashboard  :  http://localhost:${PORT}/api/dashboard/stats ║`);
  console.log('  ╚══════════════════════════════════════════════════╝');
  console.log('\n');
});
